# Discord-Bot-Template
Un projet bot Discord en discord.js v12 déjà prêt, avec handler. Plus qu'à coder vos commandes !


# Comment Débuter ?

Le fichier index.js est complet, il à pour but  de lire les commandes qui seront crées dans le dossier ./commands.
Les commandes seront lues dans le dossier commandes uniquement. Le nom de la commande est le nom du fichier de celle ci.

Par exemple le fichier ping.js sera sur Discord la commande _prefix_ping (_prefix_ étant le préfixe défini dans le fichier config.json)


# Comment créer mon bot Discord ?

Créez une application bot sur https://discord.com/developers/applications et récupérez le token pour le mettre sur la variable token dans le fichier config.json


Créez votre code dans le dossier commands en format <nom>.js

Un exemple de forme est dispo sur le fichier exemple.js
